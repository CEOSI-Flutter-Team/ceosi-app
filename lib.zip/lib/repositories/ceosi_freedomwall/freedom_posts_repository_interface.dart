abstract class FreedomPostsRepositoryInterface {
  Future<Map<String, dynamic>?> getFreedomPostsList();
}
