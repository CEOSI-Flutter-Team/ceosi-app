class CustomIcons {
  final piecharticon = 'assets/icons/piechart.png';
  final filtericon = 'assets/icons/filter.png';
  final continuousdoticon = 'assets/icons/continuousdot.png';
  final plusicon = 'assets/icons/plus.png';
  final datepickericon = 'assets/icons/datepickericon.png';
  final deleteicon = 'assets/icons/deleteicon.png';
  final editicon = 'assets/icons/editicon.png';
  final freedompostsicon = 'assets/icons/freedompostsicon.png';
}
