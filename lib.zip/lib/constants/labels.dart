class Labels {
  static const ceosiFlutterCatalog = 'CEOSI Flutter Catalog',
      ceosiFreedomWall = 'CEOSI Freedom Wall',
      ceosiCompanyApp = 'CEOSI Company App',
      ceosiRewards = 'CEOSI Rewards',
      codeList = 'CODE LIST',
      ceosiApp = 'CEOSI App',
      categories = 'Categories';
}
